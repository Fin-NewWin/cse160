#ifndef TABLE_H
#define TABLE_H

typedef nx_uint8_tuint8_t n_tab[20];

#endif
